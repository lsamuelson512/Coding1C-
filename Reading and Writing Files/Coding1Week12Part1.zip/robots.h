#include <iostream>
#include <vector>
#include <string>
using namespace std;

class robot {
    private: 
        string name;
        int charge;

    public: 

        robot() {
            name = "ROB";
            charge = 100;
        }

        robot(string userName, int userCharge) {
            name = userName;
            charge = userCharge;
        }

        string getName(){return name;}
        int getCharge(){return charge;}

        void setName(string userName){name = userName;}
        void setCharge(int userCharge){charge = userCharge;}
};