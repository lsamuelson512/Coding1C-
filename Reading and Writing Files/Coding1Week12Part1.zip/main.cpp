#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
#include "function.h"
#include "robots.h"
using namespace std;

int main() {
    ofstream myfile;
    ifstream nameFile ("names.txt");
    string line;
    vector<string> names;
    
    myfile.open("example.txt");
    myfile << "Hello World" << endl;
    myfile.close();

    if(nameFile.is_open()){
        while(getline(nameFile, line)){
            names.push_back(line);
        }
    } else {
        cout << "File not found" << endl;
        return 0;
    }

    srand(time(0));
    printMultiple(names.at(rand() % names.size()), 5);
}