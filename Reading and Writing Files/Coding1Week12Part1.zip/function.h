#include <iostream>
#include <string>
using namespace std;

void printMultiple(string printOut, int numTimes){
    for(int i = 0; i < numTimes; i++)
        cout << printOut << endl;
}